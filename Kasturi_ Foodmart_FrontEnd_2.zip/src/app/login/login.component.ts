import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isModalOpen = false;
  modalType: 'login' | 'signup' = 'login';
  constructor(private route:Router){}
  ngOnInit(): void {
    
  }
  openModal(type: 'login' | 'signup') {
    this.modalType = type;
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }
}
