import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  subtotal: number = 0;
  shipping: number = 50; // Example fixed shipping charge
  isSaveClicked: boolean = false;
  isUpdateMode: boolean = false;
  isSaving: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loadCartItems();
  }

  
  loadCartItems(): void {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartItems = cart;
    this.calculateTotals();
  }

  
  calculateTotals(): void {
    this.subtotal = this.cartItems.reduce(
      (total, item) => total + item.offerPrice * item.quantity,
      0
    );
  }

 
  removeItem(index: number): void {
    this.cartItems.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(this.cartItems));
    this.calculateTotals();
  }

  
  Logindata(): void {
    this.router.navigate(['/checkout']);
  }
}
