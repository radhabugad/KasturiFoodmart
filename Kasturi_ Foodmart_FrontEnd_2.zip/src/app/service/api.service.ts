import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';  
@Injectable({
  providedIn: 'root'
})
export class ApiService {
   baseurl="http://localhost:5125/api/";
  
  // baseurl="https://kasturifoods.api.sanisoftinfotech.com/api/";
  
  constructor(private http:HttpClient) { }

  get(path: string) {
    return this.http.get(this.baseurl + path);
  }

  post(path: string, data: any) {
    return this.http.post(this.baseurl + path, data);
  }

  put(path: string, data: any) {
    return this.http.put(this.baseurl + path, data);
  }

  delete(path: string) {
    return this.http.delete(this.baseurl + path);
  }
 


  keyPressNumbers(event:any) {
    var charCode = (event.which) ? event.which : event.keyCode;
    // Only Numbers 0-9
    if ((charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    } else {
      return true;
    }
  }

  decimalFilter(event: any) {
    const reg = /^-?\d*(\.\d{0,2})?$/;
    let input = event.target.value + String.fromCharCode(event.charCode);
 
    if (!reg.test(input)) {
        event.preventDefault();
    }
 }
 toUpperCase(event: any) {
  // Convert input value to uppercase
  event.target.value = event.target.value.toUpperCase();
}

}
