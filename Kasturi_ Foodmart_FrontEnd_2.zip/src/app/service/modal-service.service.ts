import { Injectable, OnInit } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModalServiceService implements OnInit {
  private cartData = new BehaviorSubject<number>(0);

  constructor() {
    const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartData.next(cartItems.length);
  }
  ngOnInit(): void {
    
  }

  getCartItemCount(): Observable<number> {
    // Here, you can get the count from a service or localStorage or wherever the cart data is stored
    const cartCount = 5; // Example count value
    return of(cartCount); // Returning an observable of the number type
  }

  updateCart() {
    const cartItems = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartData.next(cartItems.length);
  }

}
