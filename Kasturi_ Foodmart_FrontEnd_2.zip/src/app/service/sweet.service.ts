import { Injectable } from '@angular/core';
import Swal, { SweetAlertResult } from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class SweetService {
  error(arg0: string) {
    throw new Error('Method not implemented.');
  }
  success(arg0: string) {
    throw new Error('Method not implemented.');
  }

  constructor() { }

  showSuccess(title: string, message: string, closeModal: boolean = true): Promise<SweetAlertResult> {
    return Swal.fire({
      icon: 'success',
      title: title,
      text: message,
      background: '#f0f9ff',
      iconColor: '#4caf50',
      confirmButtonColor: '#4caf50',
      showCloseButton: closeModal,
      customClass: {
        popup: 'animated bounceIn'
      }
    });
  }

  showError(title: string, message: string): Promise<SweetAlertResult> {
    return Swal.fire({
      icon: 'error',
      title: title,
      text: message,
      background: '#ffebee',
      iconColor: '#f44336',
      confirmButtonColor: '#f44336',
      customClass: {
        popup: 'animated shake'
      }
    });
  }

  showConfirmation(title: string, message: string): Promise<SweetAlertResult> {
    return Swal.fire({
      icon: 'warning',
      title: title,
      text: message,
      background: '#fff8e1',
      iconColor: '#ffa726',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, proceed!',
      cancelButtonText: 'Cancel',
      customClass: {
        popup: 'animated fadeIn'
      }
    });
  }

  showConfirm(
    title: string, 
    text: string, 
    confirmButtonText: string, 
    cancelButtonText: string
  ): Promise<SweetAlertResult> {
    return Swal.fire({
      title: title,
      text: text,
      icon: 'info',
      background: '#e3f2fd',
      iconColor: '#2196f3',
      showCancelButton: true,
      confirmButtonText: confirmButtonText,
      cancelButtonText: cancelButtonText,
      confirmButtonColor: '#2196f3',
      cancelButtonColor: '#d33',
      customClass: {
        popup: 'animated zoomIn'
      }
    });
  }
}
