import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { SweetService } from '../service/sweet.service';

@Component({
  selector: 'app-product-insert',
  templateUrl: './product-insert.component.html',
  styleUrls: ['./product-insert.component.css']
})
export class ProductInsertComponent implements OnInit {
  selectedFiles: File[] = [];
  base64Images: string[] = [];

  constructor(private api:ApiService,private sweet:SweetService){}
  ngOnInit(): void {
   
  }
  onFileSelected(event: any): void {
    const files: FileList = event.target.files;
    this.selectedFiles = [];

    for (let i = 0; i < files.length; i++) {
      this.selectedFiles.push(files.item(i)!);
      this.getBase64Image(files.item(i)!);
    }
  }

  getBase64Image(file: File): void {
    const reader = new FileReader();

    reader.onload = (e: any) => {

      this.base64Images.push(e.target.result);
    };

    reader.readAsDataURL(file);
  }
  deleteImage(base64Image: string): void {
    const index = this.base64Images.indexOf(base64Image);
    if (index !== -1) {
      this.base64Images.splice(index, 1);
    }
  }

}
