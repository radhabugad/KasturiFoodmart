import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  Get_Product_Data: any[] = [];
  Display_Product_Data: any[] = [];
  pid: any;
  Product_All_Data: any;
  Product_Image_DAta: any[] = []; // Initialize with an empty array
  currentImageIndex: number = 0;
  imageSliderInterval: any;
  quantity: number = 0; 
  constructor(private api:ApiService){}
  ngOnInit(): void {
    this.api.get('Select_Product_List_For_Sell').subscribe((res: any) => {
      this.Get_Product_Data = res.map((product: any) => {
        if (product.image && !this.isBase64(product.image)) {
          product.image = this.convertUint8ArrayToBase64(product.image);
        }
        return product;
      });

    
      this.startStaggeredDisplay();
    });
  }
  startStaggeredDisplay(): void {
    this.Display_Product_Data = []; 
    this.Get_Product_Data.forEach((product, index) => {
      setTimeout(() => {
        this.Display_Product_Data.push(product);
      }, index * 100); 
    });
  }

  convertUint8ArrayToBase64(data: Uint8Array): string {
    return btoa(String.fromCharCode(...data));
  }

  isBase64(str: string): boolean {
    const base64Regex = /^(?:[A-Za-z0-9+\/]{4})*?(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=)?$/;
    return base64Regex.test(str);
  }
  updateQuantity(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    this.quantity = inputElement.valueAsNumber
  }
  addToCart(): void {
    console.log('Current Quantity:', this.quantity); // Debugging
    const cartItem = {
      productId: this.pid,
      name: this.Product_All_Data?.product_name,
      offerPrice: this.Product_All_Data?.offer_price,
      price: this.Product_All_Data?.price,
      description: this.Product_All_Data?.product_description,
      image: this.Product_Image_DAta.length
        ? this.Product_Image_DAta[this.currentImageIndex]?.image
        : null,
      quantity: this.quantity,
    };

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItemIndex = cart.findIndex((item: any) => item.productId === cartItem.productId);

    if (existingItemIndex >= 0) {
      cart[existingItemIndex].quantity += this.quantity;
    } else {
      cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    
  }
}
