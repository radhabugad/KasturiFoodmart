import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApiService } from '../service/api.service';
import { SweetService } from '../service/sweet.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isModalOpen = false;
  modalType: 'login' | 'signup' = 'login';
  cartItemCount: number = 0;
  login_data:any;
  isSaveClicked: boolean = false;
  isUpdateMode: boolean = false;
  isSaving: boolean = false;
  userDisplayInfo: string = '';
  isLoggedIn: boolean = false;
   loading: boolean = false;
   
  constructor(private api:ApiService,private sweet:SweetService){}
  
  ngOnInit(): void {
    this.loadCartData();
    this.load();
  }
  load(){
    this.login_data = new FormGroup({
      name:new FormControl(''),
      email:new FormControl(''),
      mobile:new FormControl(''),
      password:new FormControl('')
    })
  }
  loadCartData(): void {
    const cartData = JSON.parse(localStorage.getItem('cart') || '[]');
    this.cartItemCount = cartData.length; 
  }
  

  openModal(type: 'login' | 'signup') {
    this.modalType = type;
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }
  submit_Login_Data(data: any) {
    console.log('Submitting data:', data);
    
    this.isSaving = true;
    this.isSaveClicked = true;
  
    if (!data.mobile || !data.password) {
      if (this.modalType === 'login') {
        this.isSaving = false;
        this.sweet.showError('Error', 'Please provide your mobile number and password.');
        return;
      }
    }
  
    if (this.modalType === 'login') {
      this.api.post('Insert_Customer', data).subscribe(
        (result: any) => {
          console.log('Login API Response:', result);
  
          
          if (result === 1) {
            this.sweet.showSuccess('Success', 'Login successful');
            this.isLoggedIn = true;
            this.userDisplayInfo = result.data?.name || result.data?.email || result.data?.mobile || 'User';

            console.log(this.userDisplayInfo);
            this.closeModal();
            this.load(); 
          } else {
            this.sweet.showError('Error', 'Invalid credentials. Please try again.');
          }
  
          this.isSaving = false;
        },
        (error: any) => {
          console.error('Login API Error:', error);
          this.sweet.showError('Error', 'Failed to log in. Please check your credentials.');
          this.isSaving = false;
        }
      );
    } else if (this.modalType === 'signup') {
      if (!data.name || !data.email || !data.mobile || !data.password) {
        this.isSaving = false;
        this.sweet.showError('Error', 'Please provide your full name, email, mobile,password.');
        return;
      }
  
      this.api.post('Insert_Customer', data).subscribe(
        (result: any) => {
          console.log('Signup API Response:', result);
  
          // Check if the result is 1 for success
          if (result === 1) {
            this.sweet.showSuccess('Success', 'Account created successfully');
            this.userDisplayInfo = result.data?.name || result.data?.email || result.data?.mobile || 'User';
            this.closeModal();
          } else {
            this.sweet.showError('Error', 'Failed to create an account. Please try again.');
          }
  
          this.isSaving = false;
        },
        (error: any) => {
          console.error('Signup API Error:', error);
          this.sweet.showError('Error', 'An error occurred while creating an account. Please try again.');
          this.isSaving = false;
        }
      );
    } else {
      this.isSaving = false;
      this.sweet.showError('Error', 'Invalid operation. Please try again.');
    }
  }
  
  
  
  
  
}
