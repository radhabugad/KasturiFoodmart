import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {
  Get_Product_Data: any[] = [];
  Display_Product_Data: any[] = [];

  constructor(private api: ApiService, private route: Router) {}

  ngOnInit(): void {
   
    this.api.get('Select_Product_List_For_Sell').subscribe((res: any) => {
      this.Get_Product_Data = res.map((product: any) => {
        if (product.image && !this.isBase64(product.image)) {
          product.image = this.convertUint8ArrayToBase64(product.image);
        }
        return product;
      });

    
      this.startStaggeredDisplay();
    });
  }

  startStaggeredDisplay(): void {
    this.Display_Product_Data = []; 
    this.Get_Product_Data.forEach((product, index) => {
      setTimeout(() => {
        this.Display_Product_Data.push(product);
      }, index * 100); 
    });
  }

  convertUint8ArrayToBase64(data: Uint8Array): string {
    return btoa(String.fromCharCode(...data));
  }

  isBase64(str: string): boolean {
    const base64Regex = /^(?:[A-Za-z0-9+\/]{4})*?(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=)?$/;
    return base64Regex.test(str);
  }
  
}
