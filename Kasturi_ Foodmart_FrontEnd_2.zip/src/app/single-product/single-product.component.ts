import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../service/api.service';
import { SweetService } from '../service/sweet.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-single-product',
  templateUrl: './single-product.component.html',
  styleUrls: ['./single-product.component.css']
})
export class SingleProductComponent implements OnInit, OnDestroy {
  pid: any;
  Product_All_Data: any;
  Product_Image_DAta: any[] = []; // Initialize with an empty array
  currentImageIndex: number = 0;
  imageSliderInterval: any;
  quantity: number = 0; 


  constructor(
    private api: ApiService,
    private sweet: SweetService,
    private router: ActivatedRoute
  ) {
    this.pid = this.router.snapshot.paramMap.get('pid');
  }

  ngOnInit(): void {
   
    this.api.get(`Select_Product_Details_For_Sale/${this.pid}`).subscribe((res: any) => {
      this.Product_Image_DAta = res.select_Product_Details_For_Sale_tbl2_details;

      
      if (this.Product_Image_DAta.length) {
        this.startImageSlider();
      }

     
      this.Product_All_Data = res.select_Product_Details_For_Sale_tbl1_details[0];
    });
  }

  startImageSlider(): void {
    this.imageSliderInterval = setInterval(() => {
      this.currentImageIndex = (this.currentImageIndex + 1) % this.Product_Image_DAta.length;
    }, 4000); 
  }

  ngOnDestroy(): void {
  
    if (this.imageSliderInterval) {
      clearInterval(this.imageSliderInterval);
    }
  }
  previousImage(): void {
    this.currentImageIndex = 
      (this.currentImageIndex - 1 + this.Product_Image_DAta.length) % this.Product_Image_DAta.length;
  }
  
  nextImage(): void {
    this.currentImageIndex = 
      (this.currentImageIndex + 1) % this.Product_Image_DAta.length;
  }
  updateQuantity(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    this.quantity = inputElement.valueAsNumber
  }
  addToCart(): void {
    console.log('Current Quantity:', this.quantity); // Debugging
    const cartItem = {
      productId: this.pid,
      name: this.Product_All_Data?.product_name,
      offerPrice: this.Product_All_Data?.offer_price,
      price: this.Product_All_Data?.price,
      description: this.Product_All_Data?.product_description,
      image: this.Product_Image_DAta.length
        ? this.Product_Image_DAta[this.currentImageIndex]?.image
        : null,
      quantity: this.quantity,
    };

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItemIndex = cart.findIndex((item: any) => item.productId === cartItem.productId);

    if (existingItemIndex >= 0) {
      cart[existingItemIndex].quantity += this.quantity;
    } else {
      cart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    
  }
}

  
  
  

